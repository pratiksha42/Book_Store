<?php
include 'config.php';

if(isset($_POST['submit'])) {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, md5($_POST['password'])); // Encrypt the password
    
    $insert_admin = mysqli_query($conn, "INSERT INTO `admins` (username, email, password) VALUES ('$username', '$email', '$password')");
    
    if($insert_admin) {
        $success_message = "Admin registration successful.";
    } else {
        $error_message = "Admin registration failed.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <!-- Add your meta tags, CSS links, and title here -->
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>admin registration</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>

<?php
if(isset($error_message)){ 
    echo '
    <div class="message error">
        <span>'.$error_message.'</span>
        <i class="fas fa-times" onclick="this.parentElement.remove();"></i>
    </div>
    ';
}
if(isset($success_message)){ 
    echo '
    <div class="message success">
        <span>'.$success_message.'</span>
        <i class="fas fa-times" onclick="this.parentElement.remove();"></i>
    </div>
    ';
}
?>

<div class="form-container">
    <form action="" method="post">
        <h3>Admin Registration</h3>
        <input type="text" name="username" placeholder="Enter your username" required class="box">
        <input type="email" name="email" placeholder="Enter your email" required class="box">
        <input type="password" name="password" placeholder="Enter your password" required class="box">
        <input type="submit" name="submit" value="Register" class="btn">
        <p>already have an account? <a href="admin_login.php">login now</a></p>

    </form>
</div>

</body>
</html>
